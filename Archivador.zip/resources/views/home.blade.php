@extends('layouts.app')
@section('title', 'Home')
@section('page', 'Dashboard')
@section('content')

@endsection

